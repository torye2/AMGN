package amgn.amu.dto;

public record ReviewOrderDto(
        Long orderId,
        String itemTitle
) {}
