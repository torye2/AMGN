package amgn.amu.dto;

import lombok.Data;

@Data
public class BlockRequest {
	private Long blockedId;
}
