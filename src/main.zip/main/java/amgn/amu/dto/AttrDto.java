package amgn.amu.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttrDto {
    private String attrKey;
    private String attrValue;
}