package amgn.amu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PjAmugeonaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PjAmugeonaApplication.class, args);
    }

}
